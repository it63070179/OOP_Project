import java.io.Serializable;

public class Doc implements Serializable {
    private String Title;
    private String Type;
    private String Detail;

    public Doc() {
        this("", "", "");
    }

    public Doc(String Title, String Type, String Detail) {
        this.Title = Title;
        this.Type = Type;
        this.Detail = Detail;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String Title) {
        this.Title = Title;
    }

    public String getType() {
        return Type;
    }

    public void setType(String Type) {
        this.Type = Type;
    }

    public String getDetail() {
        return Detail;
    }

    public void setDetail(String Detail) {
        this.Detail = Detail;
    }
    
    
}
