import java.awt.*;
import javax.swing.*;
public class DocumentMainView {
    JFrame frame;
    JTextField tf1, tf2, showindex;
    JComboBox inputType;
    JButton bnadd, bnupdate, bndelete, bnleft, bnright;
    JLabel lb1, lb2, lb3;
    JPanel pnmain, pntop, pnmid, pnbot;
    
    public DocumentMainView(){
        frame = new JFrame("DocumentView");
        frame.setSize(450, 400); 
        lb1 = new JLabel("Title");
        lb2 = new JLabel("Type");
        lb3 = new JLabel("Detail");
        tf1 = new JTextField();
        inputType = new JComboBox();
        tf2 = new JTextField();
        inputType.addItem("Normal");
        inputType.addItem("Formal");
        inputType.addItem("Informal");
        inputType.addItem("etc");
        pntop = new JPanel(new GridLayout(3,3));
        pntop.add(lb1);
        pntop.add(tf1);
        pntop.add(lb2);
        pntop.add(lb3);
        pntop.add(tf2);
        pntop.add(inputType);
        
        bnleft = new JButton("Previous");
        bnright = new JButton("Next");
        showindex = new JTextField(5);
        showindex.setText("0");
        showindex.setHorizontalAlignment(JTextField.CENTER);
        pnmid = new JPanel(new FlowLayout());
        pnmid.add(bnleft);
        pnmid.add(showindex);
        pnmid.add(bnright);
        
        bnadd = new JButton("Add");
        bnupdate = new JButton("Update");
        bndelete = new JButton("Delete");
        pnbot = new JPanel(new FlowLayout());
        pnbot.add(bnadd);
        pnbot.add(bnupdate);
        pnbot.add(bndelete);
        
        pnmain = new JPanel(new GridLayout(3,1));
        pnmain.add(pntop);
        pnmain.add(pnmid);
        pnmain.add(pnbot);
        
        frame.add(pnmain, BorderLayout.NORTH);
        frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
