import java.awt.*;
import javax.swing.*;
public class DocumentDetailView {
    JFrame frame;
    JTextField tf1, tf2, showindex;
    JComboBox inputType;
    JLabel lb1, lb2, lb3;
    JPanel pnmain, pntop;
    
    public DocumentDetailView(){
        frame = new JFrame("DocumentView");
        frame.setSize(450, 400); 
        lb1 = new JLabel("Title");
        lb2 = new JLabel("Type");
        lb3 = new JLabel("Detail");
        tf1 = new JTextField();
        inputType = new JComboBox();
        tf2 = new JTextField();
        inputType.addItem("Normal");
        inputType.addItem("Formal");
        inputType.addItem("Informal");
        inputType.addItem("etc");
        pntop = new JPanel(new GridLayout(3,2));
        pntop.add(lb1);
        pntop.add(tf1);
        pntop.add(lb2);
        pntop.add(lb3);
        pntop.add(tf2);
        pntop.add(inputType);
        
        pnmain = new JPanel(new GridLayout(2,1));
        pnmain.add(pntop);
       
        frame.add(pnmain, BorderLayout.NORTH);
        frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
