import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class DocMo {
    private ArrayList Doc;
    
    public DocMo(){
        Doc = new ArrayList();
    }
    public boolean addDoc(Doc b){
        return Doc.add(b);
    }
    public Doc getDoc(int index){
        return (Doc) this.Doc.get(index);
    }
    
    public ArrayList getDoc(){
        return Doc;
    }
    public boolean openFile(){
        File f = new File("Doc.dat");
        if(f.exists()){
       
            try{
                FileInputStream fileInput = new FileInputStream(f);
                ObjectInputStream objectInput =  new ObjectInputStream(fileInput);
                ArrayList doc = (ArrayList) objectInput.readObject();
                for(int i = 0; i < doc.size(); i++){
                    Doc.add(doc.get(i));
                }
                objectInput.close();
                fileInput.close();
                return true;
            } catch (IOException e){
                System.out.println(e);
                return false;
            } catch (ClassNotFoundException c){
                System.out.println(c);
                return false;
            }
        }return false;
    }
    
    public boolean WriteFile(){
        try{
            FileOutputStream fileOutput = new FileOutputStream("Doc.dat");
            ObjectOutputStream objectOut =  new ObjectOutputStream(fileOutput);
            objectOut.writeObject(this.Doc);
            objectOut.close();
            fileOutput.close();
            return true;
        } catch (IOException e){
            System.out.println(e);
            return false;
        }
    }
}
