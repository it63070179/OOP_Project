import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.JOptionPane;

public class DocCon implements ActionListener, WindowListener{
    DocumentMainView view;
    DocMo model;
    DocumentDetailView viewAdd;
    public int index = 0;
    
    public DocCon(){
        view = new DocumentMainView();
        view.bnadd.addActionListener(this);
        view.bnupdate.addActionListener(this);
        view.bndelete.addActionListener(this);
        view.bnleft.addActionListener(this);
        view.bnright.addActionListener(this);
        view.frame.addWindowListener(this);
        model = new DocMo();
        viewAdd = new DocumentDetailView();
        
    }
    public void ChangeDoc(){
        if(this.index >= 0){
            Doc getDoc = model.getDoc(this.index);
            view.tf1.setText(getDoc.getTitle());
            view.tf2.setText(getDoc.getDetail());
            view.inputType.setSelectedItem(getDoc.getType());
            view.showindex.setText(this.index + "");
            
        }else{
            view.tf1.setText("");
            view.tf2.setText("");
            view.inputType.setSelectedItem("Normal");
            view.showindex.setText("0");
        }  
    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource().equals(view.bnadd)){
            viewAdd = new DocumentDetailView();
        }
        if (ae.getSource().equals(view.bnupdate)){
            model.getDoc(this.index).setTitle(view.tf1.getText());
            model.getDoc(this.index).setType(view.tf1.getText());
            model.getDoc(this.index).setDetail(view.tf1.getText());
            JOptionPane.showMessageDialog(null, JOptionPane.INFORMATION_MESSAGE);
            this.ChangeDoc();
        }
        if(ae.getSource().equals(view.bndelete)){
            model.getDoc().remove(this.index);
            if(this.index == model.getDoc().size()){
                this.index -= 1;
            }
            JOptionPane.showMessageDialog(null, JOptionPane.INFORMATION_MESSAGE);
            this.ChangeDoc();
        }
        if(ae.getSource().equals(view.bnleft)){
            if(this.index - 1 >= 0){
                this.index -= 1;
                this.ChangeDoc();
            }
        }
        if(ae.getSource().equals(view.bnright)){
            if(this.index + 1 < model.getDoc().size()){
                this.index += 1;
                this.ChangeDoc();
            }
        }
    }
    
    public void windowOpened(WindowEvent we){
        if(model.openFile()){
            System.out.println("Open File");
            this.ChangeDoc();
        }
        
    }
    
    public void windowClosing(WindowEvent we){
        if(model.getDoc().size() != 0){
            if(model.WriteFile()){
                System.out.println("Write File");
            }
        }
    }
    public void windowClosed(WindowEvent we){
        
    }
    public void windowIconified(WindowEvent we){
        
    }
    public void windowDeiconified(WindowEvent we){
        
    }
    public void windowActivated(WindowEvent we){
        
    }
    public void windowDeactivated(WindowEvent we){
        
    }
}

