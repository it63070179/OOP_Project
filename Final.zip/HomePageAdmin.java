
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Tanadon Parosin
 */
public class HomePageAdmin extends javax.swing.JFrame {

    private Login r2;
    private final BasicInternalFrameUI b3;
    private final BasicInternalFrameUI b4;
    private boolean IsAdd, IsUpdate, IsDelete;
    private int book_id, quantity, quantity_2, RowCount, user_id;
    private String book_name, author, userid, username, email, phonenumber, bookid, bookname, sql, author_2,
            borrowDate_2, dueDate_2, username_2, useremail, phonenum, id, bookName, userName, email_2, status, phone;
    private long l, l1, l2;
    private Date todaysDate;
    private Object[] obj;
    private Connection con;
    private Statement st;
    private ResultSet rs;
    private DefaultTableModel model;
    private PreparedStatement pst;
    private java.util.Date borrowDate, dueDate, uFromDate, uToDate;
    private java.sql.Date fromDate, toDate;

    /**
     * Creates new form HomePageAdmin
     */
    public HomePageAdmin() {
        initComponents();
        logout.setVisible(false);
        Desktop1.setVisible(true);
        Admin.setBorder(null);
        b3 = (BasicInternalFrameUI) Admin.getUI();
        b3.setNorthPane(null);
        logout.setBorder(null);
        b4 = (BasicInternalFrameUI) logout.getUI();
        b4.setNorthPane(null);
        setUserDetailsToTableinHome();
        setBookDetailsToTableinHome();
        setCardData();
        setBookDetailsToTableinManageBook();
        setUserDetailsToTableinManageUser();
        setBorrowBookDetailsToTableinViewRecord();
        setBorrowBookDetailsToTableinDefaulter();
    }

    //**Home**
    
        public void setUserDetailsToTableinHome() {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library_ms", "root", "");
                st = con.createStatement();
                rs = st.executeQuery("select * from users");
                while (rs.next()) {
                    userid = rs.getString("id");
                    username = rs.getString("username");
                    email = rs.getString("email");
                    phonenumber = rs.getString("phonenumber");
                    Object[] obj = {userid, username, email, phonenumber};
                    model = (DefaultTableModel) table_UserDetails.getModel();
                    model.addRow(obj);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public void setBookDetailsToTableinHome() {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library_ms", "root", "");
                st = con.createStatement();
                rs = st.executeQuery("select * from book_details");
                while (rs.next()) {
                    bookid = rs.getString("book_id");
                    bookname = rs.getString("book_name");
                    author = rs.getString("author");
                    quantity = rs.getInt("quantity");
                    Object[] obj = {bookid, bookname, author, quantity};
                    model = (DefaultTableModel) table_BookDetails.getModel();
                    model.addRow(obj);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    public void setCardData() {
        st = null;
        rs = null;

        l = System.currentTimeMillis();
        todaysDate = new Date(l);

        try {
            con = DBConnection.getConnection();
            st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = st.executeQuery("select * from book_details");
            rs.last();
            lb_NumBooks.setText(Integer.toString(rs.getRow()));

            rs = st.executeQuery("select * from users");
            rs.last();
            lb_NumStudents.setText(Integer.toString(rs.getRow()));

            rs = st.executeQuery("select * from borrow_book_details where status = '" + "pending" + "'");
            rs.last();
            lb_NumBorrowBooks.setText(Integer.toString(rs.getRow()));

            rs = st.executeQuery("select * from borrow_book_details where due_date < '" + todaysDate + "' and status = '" + "pending" + "'");
            rs.last();
            lb_DefaulterList.setText(Integer.toString(rs.getRow()));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //**ManageBook**
    
        public void setBookDetailsToTableinManageBook() {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library_ms", "root", "");
                st = con.createStatement();
                rs = st.executeQuery("select * from book_details");
                while (rs.next()) {
                    bookid = rs.getString("book_id");
                    bookname = rs.getString("book_name");
                    author = rs.getString("author");
                    quantity = rs.getInt("quantity");
                    Object[] obj = {bookid, bookname, author, quantity};
                    model = (DefaultTableModel) tb_BookDetails.getModel();
                    model.addRow(obj);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public boolean addBook() {
            IsAdd = false;
            book_id = Integer.parseInt(txt_BookID.getText());
            book_name = txt_BookName.getText();
            author_2 = txt_AuthorName.getText();
            quantity_2 = Integer.parseInt(txt_Quantity.getText());
            try {
                con = DBConnection.getConnection();
                sql = "insert into book_details values(?,?,?,?)";
                pst = con.prepareStatement(sql);
                pst.setInt(1, book_id);
                pst.setString(2, book_name);
                pst.setString(3, author_2);
                pst.setInt(4, quantity_2);
                RowCount = pst.executeUpdate();
                if (RowCount > 0) {
                    IsAdd = true;
                } else {
                    IsAdd = false;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return IsAdd;
        }

        public void ClearTableinManageBook() {
            model = (DefaultTableModel) tb_BookDetails.getModel();
            model.setRowCount(0);
        }

        public boolean UpdateBooks() {
            IsUpdate = false;
            book_id = Integer.parseInt(txt_BookID.getText());
            book_name = txt_BookName.getText();
            author_2 = txt_AuthorName.getText();
            quantity_2 = Integer.parseInt(txt_Quantity.getText());
            try {
                Connection con = DBConnection.getConnection();
                String sql = "update book_details set book_name = ?, author = ?, quantity = ? where book_id = ?";
                PreparedStatement pst = con.prepareStatement(sql);
                pst.setString(1, book_name);
                pst.setString(2, author_2);
                pst.setInt(3, quantity_2);
                pst.setInt(4, book_id);
                RowCount = pst.executeUpdate();
                if (RowCount > 0) {
                    IsUpdate = true;
                } else {
                    IsUpdate = false;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return IsUpdate;
        }

        public boolean DeleteBooks() {
            IsDelete = false;
            book_id = Integer.parseInt(txt_BookID.getText());
            try {
                con = DBConnection.getConnection();
                sql = "delete from book_details where book_id = ?";
                pst = con.prepareStatement(sql);
                pst.setInt(1, book_id);
                int RowCount = pst.executeUpdate();
                if (RowCount > 0) {
                    IsDelete = true;
                } else {
                    IsDelete = false;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return IsDelete;
        }

    //**ManageUser**
    public void setUserDetailsToTableinManageUser() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library_ms", "root", "");
            st = con.createStatement();
            rs = st.executeQuery("select * from users");
            while (rs.next()) {
                userid = rs.getString("id");
                username = rs.getString("username");
                email = rs.getString("email");
                phonenumber = rs.getString("phonenumber");
                Object[] obj = {userid, username, email, phonenumber};
                model = (DefaultTableModel) tb_UserDetails.getModel();
                model.addRow(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean UpdateUsers() {
        IsUpdate = false;
        user_id = Integer.parseInt(txt_UserID.getText());
        username_2 = txt_UserName.getText();
        useremail = txt_UserEmail.getText();
        phonenum = txt_UserPhonenum.getText();
        try {
            con = DBConnection.getConnection();
            sql = "update users set username = ?, email = ?, phonenumber = ? where id = ?";
            pst = con.prepareStatement(sql);
            pst.setString(1, username_2);
            pst.setString(2, useremail);
            pst.setString(3, phonenum);
            pst.setInt(4, user_id);
            RowCount = pst.executeUpdate();
            if (RowCount > 0) {
                IsUpdate = true;
            } else {
                IsUpdate = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return IsUpdate;
    }

    public boolean UpdateUserstoDB() {
        boolean IsUpdatetoDB = false;
        user_id = Integer.parseInt(txt_UserID.getText());
        username_2 = txt_UserName.getText();
        useremail = txt_UserEmail.getText();
        phonenum = txt_UserPhonenum.getText();
        try {
            con = DBConnection.getConnection();
            sql = "update borrow_book_details set user_name = ?, Email = ?, phonenumber = ? where user_id = ?";
            pst = con.prepareStatement(sql);
            pst.setString(1, username_2);
            pst.setString(2, useremail);
            pst.setString(3, phonenum);
            pst.setInt(4, user_id);
            RowCount = pst.executeUpdate();
            if (RowCount > 0) {
                IsUpdatetoDB = true;
            } else {
                IsUpdatetoDB = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return IsUpdatetoDB;
    }

    public void ClearTableinManageUser() {
        model = (DefaultTableModel) tb_UserDetails.getModel();
        model.setRowCount(0);
    }

    public boolean DeleteUsers() {
        IsDelete = false;
        user_id = Integer.parseInt(txt_UserID.getText());
        try {
            con = DBConnection.getConnection();
            sql = "delete from users where id = ?";
            pst = con.prepareStatement(sql);
            pst.setInt(1, user_id);
            RowCount = pst.executeUpdate();
            if (RowCount > 0) {
                IsDelete = true;
            } else {
                IsDelete = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return IsDelete;
    }

    //**ViewRecord**
    public void setBorrowBookDetailsToTableinViewRecord() {

        try {
            con = DBConnection.getConnection();
            pst = con.prepareStatement("select * from borrow_book_details");
            rs = pst.executeQuery();
            while (rs.next()) {
                id = rs.getString("id");
                bookName = rs.getString("book_name");
                userName = rs.getString("user_name");
                email_2 = rs.getString("email");
                /**
                 * columns ที่เพิ่มเข้ามา*
                 */
                phone = rs.getString("phonenumber");
                /**
                 * columns ที่เพิ่มเข้ามา*
                 */
                borrowDate = rs.getDate("borrow_date");
                dueDate = rs.getDate("due_date");
                status = rs.getString("status");

                Object[] obj = {id, bookName, userName, email_2, phone, borrowDate, dueDate, status};
                model = (DefaultTableModel) tb_BorrowBookDetails.getModel(); //ตาราง
                model.addRow(obj);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //method to clear table
    public void clearTableinViewRecord() {
        model = (DefaultTableModel) tb_BorrowBookDetails.getModel();
        model.setRowCount(0);
    }

    //to fetch the record using date fields
    public void search() {
        uFromDate = date_fromDate.getDate();
        uToDate = date_toDate.getDate();
        l1 = uFromDate.getTime();
        l2 = uToDate.getTime();
        fromDate = new java.sql.Date(l1);
        toDate = new java.sql.Date(l2);
        try {
            con = DBConnection.getConnection();
            sql = "select * from borrow_book_details where borrow_date BETWEEN ? and ?";
            pst = con.prepareStatement(sql);
            pst.setDate(1, fromDate);
            pst.setDate(2, toDate);
            rs = pst.executeQuery();
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(this, "No Record Found");
            } else {
                while (rs.next()) {
                    id = rs.getString("id");
                    bookName = rs.getString("book_name");
                    userName = rs.getString("user_name");
                    email_2 = rs.getString("email");
                    /**
                     * columns ที่เพิ่มเข้ามา*
                     */
                    phone = rs.getString("phonenumber");
                    /**
                     * columns ที่เพิ่มเข้ามา*
                     */
                    borrowDate_2 = rs.getString("borrow_date");
                    dueDate_2 = rs.getString("due_date");
                    status = rs.getString("status");
                    Object[] obj = {id, bookName, userName, email_2, phone, borrowDate_2, dueDate_2, status};
                    model = (DefaultTableModel) tb_BorrowBookDetails.getModel(); //ตาราง
                    model.addRow(obj);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //**DefaulterList**
    public void setBorrowBookDetailsToTableinDefaulter() {
        l = System.currentTimeMillis();
        todaysDate = new Date(l);

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library_ms", "root", "");
            pst = con.prepareStatement("select * from borrow_book_details where due_date < ? and status = ?");
            pst.setDate(1, todaysDate);
            pst.setString(2, "pending");
            rs = pst.executeQuery();

            while (rs.next()) {
                id = rs.getString("id");
                bookName = rs.getString("book_name");
                userName = rs.getString("user_name");
                email_2 = rs.getString("email");
                /**
                 * columns ที่เพิ่มเข้ามา*
                 */
                phone = rs.getString("phonenumber");
                /**
                 * columns ที่เพิ่มเข้ามา*
                 */
                borrowDate = rs.getDate("borrow_date");
                dueDate = rs.getDate("due_date");
                status = rs.getString("status");

                Object[] obj = {id, bookName, userName, email_2, phone, borrowDate, dueDate, status};
                model = (DefaultTableModel) tb_DefaulterList.getModel(); //ตาราง
                model.addRow(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Desktop1 = new javax.swing.JDesktopPane();
        logout = new javax.swing.JInternalFrame();
        jPanel35 = new javax.swing.JPanel();
        jLabel40 = new javax.swing.JLabel();
        rSMaterialButtonCircle9 = new necesario.RSMaterialButtonCircle();
        jLabel41 = new javax.swing.JLabel();
        rSMaterialButtonCircle10 = new necesario.RSMaterialButtonCircle();
        jLabel42 = new javax.swing.JLabel();
        Admin = new javax.swing.JInternalFrame();
        Tab = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        lb_DefaulterList = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        lb_NumBooks = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        lb_NumStudents = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        table_UserDetails = new rojerusan.RSTableMetro();
        jScrollPane5 = new javax.swing.JScrollPane();
        table_BookDetails = new rojerusan.RSTableMetro();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jPanel21 = new javax.swing.JPanel();
        lb_NumBorrowBooks = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jPanel20 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        jPanel23 = new javax.swing.JPanel();
        jLabel29 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txt_BookID = new app.bolivia.swing.JCTextField();
        txt_Quantity = new app.bolivia.swing.JCTextField();
        txt_BookName = new app.bolivia.swing.JCTextField();
        txt_AuthorName = new app.bolivia.swing.JCTextField();
        rSMaterialButtonCircle2 = new rojerusan.RSMaterialButtonCircle();
        rSMaterialButtonCircle3 = new rojerusan.RSMaterialButtonCircle();
        rSMaterialButtonCircle4 = new rojerusan.RSMaterialButtonCircle();
        jScrollPane6 = new javax.swing.JScrollPane();
        tb_BookDetails = new rojerusan.RSTableMetro();
        jLabel15 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jPanel24 = new javax.swing.JPanel();
        jLabel30 = new javax.swing.JLabel();
        jPanel25 = new javax.swing.JPanel();
        jLabel31 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        txt_UserID = new app.bolivia.swing.JCTextField();
        jLabel17 = new javax.swing.JLabel();
        txt_UserName = new app.bolivia.swing.JCTextField();
        jLabel18 = new javax.swing.JLabel();
        txt_UserEmail = new app.bolivia.swing.JCTextField();
        jLabel19 = new javax.swing.JLabel();
        txt_UserPhonenum = new app.bolivia.swing.JCTextField();
        rSMaterialButtonCircle5 = new rojerusan.RSMaterialButtonCircle();
        rSMaterialButtonCircle6 = new rojerusan.RSMaterialButtonCircle();
        jScrollPane7 = new javax.swing.JScrollPane();
        tb_UserDetails = new rojerusan.RSTableMetro();
        jLabel20 = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        jPanel26 = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        jPanel27 = new javax.swing.JPanel();
        jLabel33 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        rSMaterialButtonCircle7 = new rojerusan.RSMaterialButtonCircle();
        date_toDate = new com.toedter.calendar.JDateChooser();
        date_fromDate = new com.toedter.calendar.JDateChooser();
        rSMaterialButtonCircle8 = new rojerusan.RSMaterialButtonCircle();
        jLabel21 = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tb_BorrowBookDetails = new rojerusan.RSTableMetro();
        jPanel28 = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        jPanel29 = new javax.swing.JPanel();
        jLabel35 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tb_DefaulterList = new rojerusan.RSTableMetro();
        jLabel23 = new javax.swing.JLabel();
        jPanel18 = new javax.swing.JPanel();
        jPanel30 = new javax.swing.JPanel();
        jLabel36 = new javax.swing.JLabel();
        jPanel31 = new javax.swing.JPanel();
        jLabel37 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        jPanel32 = new javax.swing.JPanel();
        jLabel38 = new javax.swing.JLabel();
        jPanel33 = new javax.swing.JPanel();
        jLabel39 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        Statistic = new javax.swing.JLabel();
        Home = new javax.swing.JLabel();
        Manage_book = new javax.swing.JLabel();
        Manage_User = new javax.swing.JLabel();
        View_Record = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        Defaulter_List = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(1320, 720));
        setSize(new java.awt.Dimension(1320, 720));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Desktop1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        logout.setVisible(true);

        jPanel35.setBackground(new java.awt.Color(130, 129, 225));

        jLabel40.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/iconmonstr-log-out-1-96.png"))); // NOI18N
        jLabel40.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        rSMaterialButtonCircle9.setBackground(new java.awt.Color(228, 229, 255));
        rSMaterialButtonCircle9.setForeground(new java.awt.Color(94, 92, 200));
        rSMaterialButtonCircle9.setText("No, I changed my mind ");
        rSMaterialButtonCircle9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSMaterialButtonCircle9MouseClicked(evt);
            }
        });

        jLabel41.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(255, 255, 255));
        jLabel41.setText("Are you sure to ");

        rSMaterialButtonCircle10.setBackground(new java.awt.Color(94, 92, 200));
        rSMaterialButtonCircle10.setText("Yes, Log me out");
        rSMaterialButtonCircle10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSMaterialButtonCircle10MouseClicked(evt);
            }
        });

        jLabel42.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(255, 255, 255));
        jLabel42.setText("logout.");

        javax.swing.GroupLayout jPanel35Layout = new javax.swing.GroupLayout(jPanel35);
        jPanel35.setLayout(jPanel35Layout);
        jPanel35Layout.setHorizontalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel35Layout.createSequentialGroup()
                .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel35Layout.createSequentialGroup()
                        .addGap(157, 157, 157)
                        .addComponent(jLabel40))
                    .addGroup(jPanel35Layout.createSequentialGroup()
                        .addGap(115, 115, 115)
                        .addComponent(jLabel41))
                    .addGroup(jPanel35Layout.createSequentialGroup()
                        .addGap(161, 161, 161)
                        .addComponent(jLabel42))
                    .addGroup(jPanel35Layout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rSMaterialButtonCircle9, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rSMaterialButtonCircle10, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(67, Short.MAX_VALUE))
        );
        jPanel35Layout.setVerticalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel35Layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(jLabel40)
                .addGap(18, 18, 18)
                .addComponent(jLabel41)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel42)
                .addGap(27, 27, 27)
                .addComponent(rSMaterialButtonCircle10, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(rSMaterialButtonCircle9, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(112, 112, 112))
        );

        javax.swing.GroupLayout logoutLayout = new javax.swing.GroupLayout(logout.getContentPane());
        logout.getContentPane().setLayout(logoutLayout);
        logoutLayout.setHorizontalGroup(
            logoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel35, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        logoutLayout.setVerticalGroup(
            logoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel35, javax.swing.GroupLayout.PREFERRED_SIZE, 462, Short.MAX_VALUE)
        );

        Desktop1.add(logout, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 75, 400, 490));

        Admin.setPreferredSize(new java.awt.Dimension(1170, 740));
        Admin.setRequestFocusEnabled(false);
        Admin.setVisible(true);
        Admin.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(248, 244, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel13.setBackground(new java.awt.Color(255, 153, 0));
        jPanel13.setBorder(javax.swing.BorderFactory.createMatteBorder(10, 0, 0, 0, new java.awt.Color(185, 125, 0)));

        lb_DefaulterList.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        lb_DefaulterList.setForeground(new java.awt.Color(255, 255, 255));
        lb_DefaulterList.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/late.png"))); // NOI18N
        lb_DefaulterList.setText("0");

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(lb_DefaulterList)
                .addContainerGap(50, Short.MAX_VALUE))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lb_DefaulterList)
                .addContainerGap(38, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 99, -1, -1));

        jPanel14.setBackground(new java.awt.Color(162, 161, 227));
        jPanel14.setBorder(javax.swing.BorderFactory.createMatteBorder(10, 0, 0, 0, new java.awt.Color(72, 46, 233)));

        lb_NumBooks.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        lb_NumBooks.setForeground(new java.awt.Color(255, 255, 255));
        lb_NumBooks.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/num_of_book.png"))); // NOI18N
        lb_NumBooks.setText("0");

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(lb_NumBooks)
                .addContainerGap(50, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lb_NumBooks)
                .addContainerGap(38, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(84, 99, -1, -1));

        jPanel15.setBackground(new java.awt.Color(187, 105, 253));
        jPanel15.setBorder(javax.swing.BorderFactory.createMatteBorder(10, 0, 0, 0, new java.awt.Color(150, 46, 233)));

        lb_NumStudents.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        lb_NumStudents.setForeground(new java.awt.Color(255, 255, 255));
        lb_NumStudents.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/num_of_user.png"))); // NOI18N
        lb_NumStudents.setText("0");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(lb_NumStudents)
                .addContainerGap(50, Short.MAX_VALUE))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lb_NumStudents)
                .addContainerGap(38, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(338, 99, -1, -1));

        table_UserDetails.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "User ID", "Username", "Email", "Phone"
            }
        ));
        table_UserDetails.setColorBackgoundHead(new java.awt.Color(94, 92, 200));
        table_UserDetails.setColorBordeFilas(new java.awt.Color(51, 0, 102));
        table_UserDetails.setColorBordeHead(new java.awt.Color(51, 0, 102));
        table_UserDetails.setColorFilasBackgound1(new java.awt.Color(228, 229, 255));
        table_UserDetails.setColorFilasBackgound2(new java.awt.Color(228, 229, 255));
        table_UserDetails.setIntercellSpacing(new java.awt.Dimension(0, 0));
        table_UserDetails.setRowHeight(35);
        jScrollPane4.setViewportView(table_UserDetails);

        jPanel2.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 280, 504, 212));

        table_BookDetails.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Book ID", "Book Name", "Auther", "Quantity"
            }
        ));
        table_BookDetails.setColorBackgoundHead(new java.awt.Color(94, 92, 200));
        table_BookDetails.setColorBordeFilas(new java.awt.Color(51, 0, 102));
        table_BookDetails.setColorBordeHead(new java.awt.Color(51, 0, 102));
        table_BookDetails.setColorFilasBackgound1(new java.awt.Color(228, 229, 255));
        table_BookDetails.setColorFilasBackgound2(new java.awt.Color(228, 229, 255));
        table_BookDetails.setEnabled(false);
        table_BookDetails.setIntercellSpacing(new java.awt.Dimension(0, 0));
        table_BookDetails.setRowHeight(35);
        jScrollPane5.setViewportView(table_BookDetails);

        jPanel2.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(596, 280, 504, 212));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 0, 153));
        jLabel2.setText("User Details");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 237, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 0, 153));
        jLabel3.setText("Book Details");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(596, 237, -1, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(51, 0, 153));
        jLabel7.setText("No. Of Book");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(96, 56, -1, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(51, 0, 153));
        jLabel8.setText("No. Of User");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(366, 56, -1, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(51, 0, 153));
        jLabel9.setText("Book Borrowed");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(636, 56, -1, -1));

        jPanel21.setBackground(new java.awt.Color(252, 104, 184));
        jPanel21.setBorder(javax.swing.BorderFactory.createMatteBorder(10, 0, 0, 0, new java.awt.Color(233, 46, 147)));

        lb_NumBorrowBooks.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        lb_NumBorrowBooks.setForeground(new java.awt.Color(255, 255, 255));
        lb_NumBorrowBooks.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/borrowbook.png"))); // NOI18N
        lb_NumBorrowBooks.setText("0");

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(lb_NumBorrowBooks)
                .addContainerGap(50, Short.MAX_VALUE))
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lb_NumBorrowBooks)
                .addContainerGap(38, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(625, 99, -1, -1));

        jLabel28.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(51, 0, 153));
        jLabel28.setText("Defaulter");
        jPanel2.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(913, 56, -1, -1));

        jPanel20.setBackground(new java.awt.Color(0, 0, 255));
        jPanel20.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel20.setPreferredSize(new java.awt.Dimension(60, 45));
        jPanel20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel20MouseClicked(evt);
            }
        });
        jPanel20.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel26.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setText("-");
        jPanel20.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 12, -1, 20));

        jPanel2.add(jPanel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 0, -1, -1));

        jPanel23.setBackground(new java.awt.Color(255, 51, 102));
        jPanel23.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel23.setPreferredSize(new java.awt.Dimension(60, 45));
        jPanel23.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel23MouseClicked(evt);
            }
        });
        jPanel23.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel29.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(255, 255, 255));
        jLabel29.setText("X");
        jPanel23.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 12, -1, -1));

        jPanel2.add(jPanel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 0, 60, -1));

        Tab.addTab("Home", jPanel2);

        jPanel3.setBackground(new java.awt.Color(248, 244, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel5.setBackground(new java.awt.Color(77, 75, 156));

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Book ID");

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Quantity");

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Book Name");

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Auther Name");

        txt_BookID.setBackground(new java.awt.Color(77, 75, 156));
        txt_BookID.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_BookID.setForeground(new java.awt.Color(255, 255, 255));
        txt_BookID.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txt_BookID.setPhColor(new java.awt.Color(187, 187, 225));
        txt_BookID.setPlaceholder("Enter Book ID");
        txt_BookID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_BookIDActionPerformed(evt);
            }
        });

        txt_Quantity.setBackground(new java.awt.Color(77, 75, 156));
        txt_Quantity.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_Quantity.setForeground(new java.awt.Color(255, 255, 255));
        txt_Quantity.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txt_Quantity.setPhColor(new java.awt.Color(187, 187, 225));
        txt_Quantity.setPlaceholder("Enter Quantity");
        txt_Quantity.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_QuantityActionPerformed(evt);
            }
        });

        txt_BookName.setBackground(new java.awt.Color(77, 75, 156));
        txt_BookName.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_BookName.setForeground(new java.awt.Color(255, 255, 255));
        txt_BookName.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txt_BookName.setPhColor(new java.awt.Color(187, 187, 225));
        txt_BookName.setPlaceholder("Enter Book Name");
        txt_BookName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_BookNameActionPerformed(evt);
            }
        });

        txt_AuthorName.setBackground(new java.awt.Color(77, 75, 156));
        txt_AuthorName.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_AuthorName.setForeground(new java.awt.Color(255, 255, 255));
        txt_AuthorName.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txt_AuthorName.setPhColor(new java.awt.Color(187, 187, 225));
        txt_AuthorName.setPlaceholder("Enter Auther Name");
        txt_AuthorName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_AuthorNameActionPerformed(evt);
            }
        });

        rSMaterialButtonCircle2.setBackground(new java.awt.Color(74, 189, 45));
        rSMaterialButtonCircle2.setText("ADD");
        rSMaterialButtonCircle2.setFont(new java.awt.Font("Roboto Medium", 1, 17)); // NOI18N
        rSMaterialButtonCircle2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonCircle2ActionPerformed(evt);
            }
        });

        rSMaterialButtonCircle3.setBackground(new java.awt.Color(242, 29, 106));
        rSMaterialButtonCircle3.setText("Delete");
        rSMaterialButtonCircle3.setFont(new java.awt.Font("Roboto Medium", 1, 17)); // NOI18N
        rSMaterialButtonCircle3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonCircle3ActionPerformed(evt);
            }
        });

        rSMaterialButtonCircle4.setBackground(new java.awt.Color(249, 185, 20));
        rSMaterialButtonCircle4.setText("Update");
        rSMaterialButtonCircle4.setFont(new java.awt.Font("Roboto Medium", 1, 17)); // NOI18N
        rSMaterialButtonCircle4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonCircle4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel14)
                    .addComponent(txt_Quantity, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txt_BookID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txt_BookName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel12)
                    .addComponent(jLabel10)
                    .addComponent(txt_AuthorName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel11)
                    .addComponent(rSMaterialButtonCircle2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(rSMaterialButtonCircle4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(rSMaterialButtonCircle3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(75, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txt_BookID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel12)
                .addGap(18, 18, 18)
                .addComponent(txt_BookName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel14)
                .addGap(18, 18, 18)
                .addComponent(txt_AuthorName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel11)
                .addGap(18, 18, 18)
                .addComponent(txt_Quantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(rSMaterialButtonCircle2, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(rSMaterialButtonCircle4, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(rSMaterialButtonCircle3, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(55, Short.MAX_VALUE))
        );

        jPanel3.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 720));

        tb_BookDetails.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Book ID", "Book Name", "Auther", "Quantity"
            }
        ));
        tb_BookDetails.setColorBackgoundHead(new java.awt.Color(94, 92, 200));
        tb_BookDetails.setColorBordeFilas(new java.awt.Color(51, 0, 102));
        tb_BookDetails.setColorBordeHead(new java.awt.Color(51, 0, 102));
        tb_BookDetails.setColorFilasBackgound1(new java.awt.Color(228, 229, 255));
        tb_BookDetails.setColorFilasBackgound2(new java.awt.Color(228, 229, 255));
        tb_BookDetails.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tb_BookDetails.setFuenteFilas(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        tb_BookDetails.setFuenteFilasSelect(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        tb_BookDetails.setIntercellSpacing(new java.awt.Dimension(0, 0));
        tb_BookDetails.setRowHeight(35);
        jScrollPane6.setViewportView(tb_BookDetails);

        jPanel3.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 190, 625, 215));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(29, 13, 128));
        jLabel15.setText("Manage Book");
        jPanel3.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(625, 80, -1, -1));

        jPanel11.setBackground(new java.awt.Color(94, 92, 200));
        jPanel11.setPreferredSize(new java.awt.Dimension(469, 2));

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 469, Short.MAX_VALUE)
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        jPanel3.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(518, 137, -1, 8));

        jPanel24.setBackground(new java.awt.Color(0, 0, 255));
        jPanel24.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel24.setPreferredSize(new java.awt.Dimension(60, 45));
        jPanel24.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel24MouseClicked(evt);
            }
        });
        jPanel24.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel30.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(255, 255, 255));
        jLabel30.setText("-");
        jPanel24.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 12, -1, 20));

        jPanel3.add(jPanel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 0, -1, -1));

        jPanel25.setBackground(new java.awt.Color(255, 51, 102));
        jPanel25.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel25.setPreferredSize(new java.awt.Dimension(60, 45));
        jPanel25.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel25MouseClicked(evt);
            }
        });
        jPanel25.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel31.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(255, 255, 255));
        jLabel31.setText("X");
        jPanel25.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 12, -1, -1));

        jPanel3.add(jPanel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 0, 60, -1));

        Tab.addTab("MBook", jPanel3);

        jPanel4.setBackground(new java.awt.Color(248, 244, 255));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel7.setBackground(new java.awt.Color(77, 75, 156));

        jLabel16.setBackground(new java.awt.Color(255, 255, 255));
        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("User ID");

        txt_UserID.setBackground(new java.awt.Color(77, 75, 156));
        txt_UserID.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_UserID.setForeground(new java.awt.Color(255, 255, 255));
        txt_UserID.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txt_UserID.setPhColor(new java.awt.Color(187, 187, 225));
        txt_UserID.setPlaceholder("Enter User ID");
        txt_UserID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_UserIDActionPerformed(evt);
            }
        });

        jLabel17.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Username");

        txt_UserName.setBackground(new java.awt.Color(77, 75, 156));
        txt_UserName.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_UserName.setForeground(new java.awt.Color(255, 255, 255));
        txt_UserName.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txt_UserName.setPhColor(new java.awt.Color(187, 187, 225));
        txt_UserName.setPlaceholder("Enter Username");
        txt_UserName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_UserNameActionPerformed(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("Email");

        txt_UserEmail.setBackground(new java.awt.Color(77, 75, 156));
        txt_UserEmail.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_UserEmail.setForeground(new java.awt.Color(255, 255, 255));
        txt_UserEmail.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txt_UserEmail.setPhColor(new java.awt.Color(187, 187, 225));
        txt_UserEmail.setPlaceholder("Enter Email");
        txt_UserEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_UserEmailActionPerformed(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Phone Number");

        txt_UserPhonenum.setBackground(new java.awt.Color(77, 75, 156));
        txt_UserPhonenum.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_UserPhonenum.setForeground(new java.awt.Color(255, 255, 255));
        txt_UserPhonenum.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txt_UserPhonenum.setPhColor(new java.awt.Color(187, 187, 225));
        txt_UserPhonenum.setPlaceholder("Enter Phone Number");
        txt_UserPhonenum.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_UserPhonenumActionPerformed(evt);
            }
        });

        rSMaterialButtonCircle5.setBackground(new java.awt.Color(249, 185, 20));
        rSMaterialButtonCircle5.setText("Update");
        rSMaterialButtonCircle5.setFont(new java.awt.Font("Roboto Medium", 1, 17)); // NOI18N
        rSMaterialButtonCircle5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonCircle5ActionPerformed(evt);
            }
        });

        rSMaterialButtonCircle6.setBackground(new java.awt.Color(242, 29, 106));
        rSMaterialButtonCircle6.setText("Delete");
        rSMaterialButtonCircle6.setFont(new java.awt.Font("Roboto Medium", 1, 17)); // NOI18N
        rSMaterialButtonCircle6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonCircle6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel18)
                    .addComponent(txt_UserPhonenum, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txt_UserID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txt_UserName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel17)
                    .addComponent(jLabel16)
                    .addComponent(txt_UserEmail, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel19)
                    .addComponent(rSMaterialButtonCircle5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(rSMaterialButtonCircle6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(75, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addComponent(jLabel16)
                .addGap(25, 25, 25)
                .addComponent(txt_UserID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25)
                .addComponent(jLabel17)
                .addGap(25, 25, 25)
                .addComponent(txt_UserName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25)
                .addComponent(jLabel18)
                .addGap(25, 25, 25)
                .addComponent(txt_UserEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25)
                .addComponent(jLabel19)
                .addGap(25, 25, 25)
                .addComponent(txt_UserPhonenum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(rSMaterialButtonCircle5, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(rSMaterialButtonCircle6, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(72, Short.MAX_VALUE))
        );

        jPanel4.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 720));

        tb_UserDetails.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "User ID", "Username", "Email", "Phone"
            }
        ));
        tb_UserDetails.setColorBackgoundHead(new java.awt.Color(94, 92, 200));
        tb_UserDetails.setColorBordeFilas(new java.awt.Color(51, 0, 102));
        tb_UserDetails.setColorBordeHead(new java.awt.Color(51, 0, 102));
        tb_UserDetails.setColorFilasBackgound1(new java.awt.Color(228, 229, 255));
        tb_UserDetails.setColorFilasBackgound2(new java.awt.Color(228, 229, 255));
        tb_UserDetails.setIntercellSpacing(new java.awt.Dimension(0, 0));
        tb_UserDetails.setRowHeight(35);
        jScrollPane7.setViewportView(tb_UserDetails);

        jPanel4.add(jScrollPane7, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 190, 625, 215));

        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(29, 13, 128));
        jLabel20.setText("Manage User");
        jPanel4.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(625, 80, -1, -1));

        jPanel16.setBackground(new java.awt.Color(94, 92, 200));
        jPanel16.setPreferredSize(new java.awt.Dimension(469, 2));

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 469, Short.MAX_VALUE)
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        jPanel4.add(jPanel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(518, 137, -1, 8));

        jPanel26.setBackground(new java.awt.Color(0, 0, 255));
        jPanel26.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel26.setPreferredSize(new java.awt.Dimension(60, 45));
        jPanel26.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel26MouseClicked(evt);
            }
        });
        jPanel26.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel32.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(255, 255, 255));
        jLabel32.setText("-");
        jPanel26.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 12, -1, 20));

        jPanel4.add(jPanel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 0, -1, -1));

        jPanel27.setBackground(new java.awt.Color(255, 51, 102));
        jPanel27.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel27.setPreferredSize(new java.awt.Dimension(60, 45));
        jPanel27.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel27MouseClicked(evt);
            }
        });
        jPanel27.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel33.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(255, 255, 255));
        jLabel33.setText("X");
        jPanel27.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 12, -1, -1));

        jPanel4.add(jPanel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 0, 60, -1));

        Tab.addTab("MUser", jPanel4);

        jPanel6.setBackground(new java.awt.Color(248, 244, 255));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel9.setBackground(new java.awt.Color(77, 75, 156));

        jLabel22.setBackground(new java.awt.Color(255, 255, 255));
        jLabel22.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setText("Borrow Date");

        jLabel24.setBackground(new java.awt.Color(255, 255, 255));
        jLabel24.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setText("Borrow Date");

        rSMaterialButtonCircle7.setBackground(new java.awt.Color(134, 132, 223));
        rSMaterialButtonCircle7.setText("ALL");
        rSMaterialButtonCircle7.setFont(new java.awt.Font("Roboto Medium", 1, 17)); // NOI18N
        rSMaterialButtonCircle7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonCircle7ActionPerformed(evt);
            }
        });

        rSMaterialButtonCircle8.setBackground(new java.awt.Color(134, 132, 223));
        rSMaterialButtonCircle8.setText("Search");
        rSMaterialButtonCircle8.setFont(new java.awt.Font("Roboto Medium", 1, 17)); // NOI18N
        rSMaterialButtonCircle8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonCircle8ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(date_fromDate, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22)
                    .addComponent(jLabel24)
                    .addComponent(date_toDate, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(75, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(rSMaterialButtonCircle8, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rSMaterialButtonCircle7, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(122, 122, 122)
                .addComponent(jLabel22)
                .addGap(30, 30, 30)
                .addComponent(date_fromDate, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45)
                .addComponent(jLabel24)
                .addGap(30, 30, 30)
                .addComponent(date_toDate, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 65, Short.MAX_VALUE)
                .addComponent(rSMaterialButtonCircle8, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(rSMaterialButtonCircle7, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(168, 168, 168))
        );

        jPanel6.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 720));

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(29, 13, 128));
        jLabel21.setText("View All Record");
        jPanel6.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(641, 80, -1, -1));

        jPanel17.setBackground(new java.awt.Color(94, 92, 200));
        jPanel17.setPreferredSize(new java.awt.Dimension(469, 2));

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 469, Short.MAX_VALUE)
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        jPanel6.add(jPanel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(534, 137, -1, 8));

        tb_BorrowBookDetails.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Book Name", "Username", "Email", "Phone ", "Borrow Date", "Due Date", "Status"
            }
        ));
        tb_BorrowBookDetails.setColorBackgoundHead(new java.awt.Color(94, 92, 200));
        tb_BorrowBookDetails.setColorBordeFilas(new java.awt.Color(0, 0, 102));
        tb_BorrowBookDetails.setColorBordeHead(new java.awt.Color(0, 0, 102));
        tb_BorrowBookDetails.setColorFilasBackgound1(new java.awt.Color(228, 229, 255));
        tb_BorrowBookDetails.setColorFilasBackgound2(new java.awt.Color(228, 229, 255));
        tb_BorrowBookDetails.setFuenteHead(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        tb_BorrowBookDetails.setIntercellSpacing(new java.awt.Dimension(0, 0));
        tb_BorrowBookDetails.setRowHeight(30);
        jScrollPane1.setViewportView(tb_BorrowBookDetails);

        jPanel6.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(349, 190, 774, 191));

        jPanel28.setBackground(new java.awt.Color(0, 0, 255));
        jPanel28.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel28.setPreferredSize(new java.awt.Dimension(60, 45));
        jPanel28.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel28MouseClicked(evt);
            }
        });
        jPanel28.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel34.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setText("-");
        jPanel28.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 12, -1, 20));

        jPanel6.add(jPanel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 0, -1, -1));

        jPanel29.setBackground(new java.awt.Color(255, 51, 102));
        jPanel29.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel29.setPreferredSize(new java.awt.Dimension(60, 45));
        jPanel29.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel29MouseClicked(evt);
            }
        });
        jPanel29.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel35.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(255, 255, 255));
        jLabel35.setText("X");
        jPanel29.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 12, -1, -1));

        jPanel6.add(jPanel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 0, 60, -1));

        Tab.addTab("Record", jPanel6);

        jPanel8.setBackground(new java.awt.Color(248, 244, 255));
        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tb_DefaulterList.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Book Name", "Username", "Email", "Phone ", "Borrow Date", "Due Date", "Status"
            }
        ));
        tb_DefaulterList.setColorBackgoundHead(new java.awt.Color(94, 92, 200));
        tb_DefaulterList.setColorBordeFilas(new java.awt.Color(0, 0, 102));
        tb_DefaulterList.setColorBordeHead(new java.awt.Color(0, 0, 102));
        tb_DefaulterList.setColorFilasBackgound1(new java.awt.Color(228, 225, 255));
        tb_DefaulterList.setColorFilasBackgound2(new java.awt.Color(228, 225, 255));
        tb_DefaulterList.setFuenteHead(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        tb_DefaulterList.setIntercellSpacing(new java.awt.Dimension(0, 0));
        tb_DefaulterList.setRowHeight(30);
        jScrollPane2.setViewportView(tb_DefaulterList);

        jPanel8.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 228, 1050, 191));

        jLabel23.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(29, 13, 128));
        jLabel23.setText("Defaulter List");
        jPanel8.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(444, 80, -1, -1));

        jPanel18.setBackground(new java.awt.Color(94, 92, 200));
        jPanel18.setPreferredSize(new java.awt.Dimension(469, 2));

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 469, Short.MAX_VALUE)
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        jPanel8.add(jPanel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(345, 142, -1, 8));

        jPanel30.setBackground(new java.awt.Color(0, 0, 255));
        jPanel30.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel30.setPreferredSize(new java.awt.Dimension(60, 45));
        jPanel30.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel30MouseClicked(evt);
            }
        });
        jPanel30.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel36.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 255));
        jLabel36.setText("-");
        jPanel30.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 12, -1, 20));

        jPanel8.add(jPanel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 0, -1, -1));

        jPanel31.setBackground(new java.awt.Color(255, 51, 102));
        jPanel31.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel31.setPreferredSize(new java.awt.Dimension(60, 45));
        jPanel31.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel31MouseClicked(evt);
            }
        });
        jPanel31.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel37.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(255, 255, 255));
        jLabel37.setText("X");
        jPanel31.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 12, -1, -1));

        jPanel8.add(jPanel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 0, 60, -1));

        Tab.addTab("Defaulter", jPanel8);

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));
        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel12.setBackground(new java.awt.Color(248, 244, 255));
        jPanel12.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel19.setBackground(new java.awt.Color(94, 92, 200));
        jPanel19.setPreferredSize(new java.awt.Dimension(469, 2));

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 469, Short.MAX_VALUE)
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        jPanel12.add(jPanel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(349, 142, -1, 8));

        jLabel25.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(29, 13, 128));
        jLabel25.setText("Dashboard");
        jPanel12.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(475, 80, -1, -1));

        jPanel32.setBackground(new java.awt.Color(0, 0, 255));
        jPanel32.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel32.setPreferredSize(new java.awt.Dimension(60, 45));
        jPanel32.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel32MouseClicked(evt);
            }
        });
        jPanel32.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel38.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setText("-");
        jPanel32.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 12, -1, 20));

        jPanel12.add(jPanel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 0, -1, -1));

        jPanel33.setBackground(new java.awt.Color(255, 51, 102));
        jPanel33.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel33.setPreferredSize(new java.awt.Dimension(60, 45));
        jPanel33.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel33MouseClicked(evt);
            }
        });
        jPanel33.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel39.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(255, 255, 255));
        jLabel39.setText("X");
        jPanel33.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 12, -1, -1));

        jPanel12.add(jPanel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 0, 60, -1));

        jPanel10.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1150, 720));

        Tab.addTab("Graph", jPanel10);

        Admin.getContentPane().add(Tab, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -30, 1160, 740));
        Tab.getAccessibleContext().setAccessibleName("Home");

        Desktop1.add(Admin, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1163, 740));

        getContentPane().add(Desktop1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 0, 1163, 720));

        jPanel1.setBackground(new java.awt.Color(94, 92, 200));

        jLabel5.setText("jLabel5");

        Statistic.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/graph.png"))); // NOI18N
        Statistic.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Statistic.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                StatisticMouseClicked(evt);
            }
        });

        Home.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/home.png"))); // NOI18N
        Home.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Home.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                HomeMouseClicked(evt);
            }
        });

        Manage_book.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/book.png"))); // NOI18N
        Manage_book.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Manage_book.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Manage_bookMouseClicked(evt);
            }
        });

        Manage_User.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/admin.png"))); // NOI18N
        Manage_User.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Manage_User.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Manage_UserMouseClicked(evt);
            }
        });

        View_Record.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/folder.png"))); // NOI18N
        View_Record.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        View_Record.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                View_RecordMouseClicked(evt);
            }
        });

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/iconmonstr-log-out-1-96.png"))); // NOI18N
        jLabel13.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel13MouseClicked(evt);
            }
        });

        Defaulter_List.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/overdue.png"))); // NOI18N
        Defaulter_List.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Defaulter_List.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Defaulter_ListMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(135, 135, 135)
                        .addComponent(jLabel5))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Manage_book)
                            .addComponent(Home)
                            .addComponent(Manage_User)
                            .addComponent(View_Record)
                            .addComponent(Defaulter_List)
                            .addComponent(Statistic)
                            .addComponent(jLabel13))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(Home)
                .addGap(18, 18, 18)
                .addComponent(Manage_book)
                .addGap(22, 22, 22)
                .addComponent(Manage_User)
                .addGap(22, 22, 22)
                .addComponent(View_Record)
                .addGap(22, 22, 22)
                .addComponent(Defaulter_List)
                .addGap(22, 22, 22)
                .addComponent(Statistic)
                .addGap(22, 22, 22)
                .addComponent(jLabel13)
                .addGap(318, 318, 318)
                .addComponent(jLabel5)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 150, 740));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jPanel33MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel33MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jPanel33MouseClicked

    private void jPanel32MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel32MouseClicked
        this.setExtendedState(HomePageAdmin.ICONIFIED);
    }//GEN-LAST:event_jPanel32MouseClicked

    private void jPanel31MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel31MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jPanel31MouseClicked

    private void jPanel30MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel30MouseClicked
        this.setExtendedState(HomePageAdmin.ICONIFIED);
    }//GEN-LAST:event_jPanel30MouseClicked

    private void jPanel29MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel29MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jPanel29MouseClicked

    private void jPanel28MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel28MouseClicked
        this.setExtendedState(HomePageAdmin.ICONIFIED);
    }//GEN-LAST:event_jPanel28MouseClicked

    private void rSMaterialButtonCircle8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonCircle8ActionPerformed
        clearTableinViewRecord();
        search();
    }//GEN-LAST:event_rSMaterialButtonCircle8ActionPerformed

    private void rSMaterialButtonCircle7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonCircle7ActionPerformed
        clearTableinViewRecord();
        setBorrowBookDetailsToTableinViewRecord();
    }//GEN-LAST:event_rSMaterialButtonCircle7ActionPerformed

    private void jPanel27MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel27MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jPanel27MouseClicked

    private void jPanel26MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel26MouseClicked
        this.setExtendedState(HomePageAdmin.ICONIFIED);
    }//GEN-LAST:event_jPanel26MouseClicked

    private void rSMaterialButtonCircle6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonCircle6ActionPerformed
        if (DeleteUsers() == true) {
            JOptionPane.showMessageDialog(this, "User Deleted");
            ClearTableinManageUser();
            setUserDetailsToTableinManageUser();
        } else {
            JOptionPane.showMessageDialog(this, "User Deletion Failed");
        }
    }//GEN-LAST:event_rSMaterialButtonCircle6ActionPerformed

    private void rSMaterialButtonCircle5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonCircle5ActionPerformed
        if (UpdateUsers() == true && UpdateUserstoDB() == true) {
            JOptionPane.showMessageDialog(this, "User Updated");
            ClearTableinManageUser();
            setUserDetailsToTableinManageUser();
        } else {
            JOptionPane.showMessageDialog(this, "User Updation Failed");
        }
    }//GEN-LAST:event_rSMaterialButtonCircle5ActionPerformed

    private void txt_UserPhonenumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_UserPhonenumActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_UserPhonenumActionPerformed

    private void txt_UserEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_UserEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_UserEmailActionPerformed

    private void txt_UserNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_UserNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_UserNameActionPerformed

    private void txt_UserIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_UserIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_UserIDActionPerformed

    private void jPanel25MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel25MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jPanel25MouseClicked

    private void jPanel24MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel24MouseClicked
        this.setExtendedState(HomePageAdmin.ICONIFIED);
    }//GEN-LAST:event_jPanel24MouseClicked

    private void rSMaterialButtonCircle4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonCircle4ActionPerformed
        if (UpdateBooks() == true) {
            JOptionPane.showMessageDialog(this, "Book Updated");
            ClearTableinManageBook();
            setBookDetailsToTableinManageBook();
        } else {
            JOptionPane.showMessageDialog(this, "Book Updation Failed");
        }
    }//GEN-LAST:event_rSMaterialButtonCircle4ActionPerformed

    private void rSMaterialButtonCircle3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonCircle3ActionPerformed
        if (DeleteBooks() == true) {
            JOptionPane.showMessageDialog(this, "Book Deleted");
            ClearTableinManageBook();
            setBookDetailsToTableinManageBook();
        } else {
            JOptionPane.showMessageDialog(this, "Book Deletion Failed");
        }
    }//GEN-LAST:event_rSMaterialButtonCircle3ActionPerformed

    private void rSMaterialButtonCircle2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonCircle2ActionPerformed
        if (addBook() == true) {
            JOptionPane.showMessageDialog(this, "Book Added");
            ClearTableinManageBook();
            setBookDetailsToTableinManageBook();
        } else {
            JOptionPane.showMessageDialog(this, "Book Addition Failed");
        }
    }//GEN-LAST:event_rSMaterialButtonCircle2ActionPerformed

    private void txt_AuthorNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_AuthorNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_AuthorNameActionPerformed

    private void txt_BookNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_BookNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_BookNameActionPerformed

    private void txt_QuantityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_QuantityActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_QuantityActionPerformed

    private void txt_BookIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_BookIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_BookIDActionPerformed

    private void jPanel23MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel23MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jPanel23MouseClicked

    private void jPanel20MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel20MouseClicked
        this.setExtendedState(HomePageAdmin.ICONIFIED);
    }//GEN-LAST:event_jPanel20MouseClicked

    private void rSMaterialButtonCircle10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSMaterialButtonCircle10MouseClicked
        // TODO add your handling code here:
        r2 = new Login();
        r2.setVisible(true);
        this.dispose();

    }//GEN-LAST:event_rSMaterialButtonCircle10MouseClicked

    private void rSMaterialButtonCircle9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSMaterialButtonCircle9MouseClicked
        logout.setVisible(false);

    }//GEN-LAST:event_rSMaterialButtonCircle9MouseClicked

    private void Defaulter_ListMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Defaulter_ListMouseClicked
        Tab.setSelectedIndex(4);
    }//GEN-LAST:event_Defaulter_ListMouseClicked

    private void jLabel13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel13MouseClicked
        logout.setVisible(true);
        logout.toFront();
    }//GEN-LAST:event_jLabel13MouseClicked

    private void View_RecordMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_View_RecordMouseClicked
        Tab.setSelectedIndex(3);
    }//GEN-LAST:event_View_RecordMouseClicked

    private void Manage_UserMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Manage_UserMouseClicked
        Tab.setSelectedIndex(2);
    }//GEN-LAST:event_Manage_UserMouseClicked

    private void Manage_bookMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Manage_bookMouseClicked
        Tab.setSelectedIndex(1);
    }//GEN-LAST:event_Manage_bookMouseClicked

    private void HomeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HomeMouseClicked
        Tab.setSelectedIndex(0);
    }//GEN-LAST:event_HomeMouseClicked

    private void StatisticMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_StatisticMouseClicked
        Tab.setSelectedIndex(5);
    }//GEN-LAST:event_StatisticMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HomePageAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HomePageAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HomePageAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HomePageAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HomePageAdmin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JInternalFrame Admin;
    private javax.swing.JLabel Defaulter_List;
    private javax.swing.JDesktopPane Desktop1;
    private javax.swing.JLabel Home;
    private javax.swing.JLabel Manage_User;
    private javax.swing.JLabel Manage_book;
    private javax.swing.JLabel Statistic;
    private javax.swing.JTabbedPane Tab;
    private javax.swing.JLabel View_Record;
    private com.toedter.calendar.JDateChooser date_fromDate;
    private com.toedter.calendar.JDateChooser date_toDate;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JLabel lb_DefaulterList;
    private javax.swing.JLabel lb_NumBooks;
    private javax.swing.JLabel lb_NumBorrowBooks;
    private javax.swing.JLabel lb_NumStudents;
    private javax.swing.JInternalFrame logout;
    private necesario.RSMaterialButtonCircle rSMaterialButtonCircle10;
    private rojerusan.RSMaterialButtonCircle rSMaterialButtonCircle2;
    private rojerusan.RSMaterialButtonCircle rSMaterialButtonCircle3;
    private rojerusan.RSMaterialButtonCircle rSMaterialButtonCircle4;
    private rojerusan.RSMaterialButtonCircle rSMaterialButtonCircle5;
    private rojerusan.RSMaterialButtonCircle rSMaterialButtonCircle6;
    private rojerusan.RSMaterialButtonCircle rSMaterialButtonCircle7;
    private rojerusan.RSMaterialButtonCircle rSMaterialButtonCircle8;
    private necesario.RSMaterialButtonCircle rSMaterialButtonCircle9;
    private rojerusan.RSTableMetro table_BookDetails;
    private rojerusan.RSTableMetro table_UserDetails;
    private rojerusan.RSTableMetro tb_BookDetails;
    private rojerusan.RSTableMetro tb_BorrowBookDetails;
    private rojerusan.RSTableMetro tb_DefaulterList;
    private rojerusan.RSTableMetro tb_UserDetails;
    private app.bolivia.swing.JCTextField txt_AuthorName;
    private app.bolivia.swing.JCTextField txt_BookID;
    private app.bolivia.swing.JCTextField txt_BookName;
    private app.bolivia.swing.JCTextField txt_Quantity;
    private app.bolivia.swing.JCTextField txt_UserEmail;
    private app.bolivia.swing.JCTextField txt_UserID;
    private app.bolivia.swing.JCTextField txt_UserName;
    private app.bolivia.swing.JCTextField txt_UserPhonenum;
    // End of variables declaration//GEN-END:variables
}
