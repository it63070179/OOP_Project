/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import java.util.regex.*;

/**
 *
 * @author TUF
 */
public class SignUp extends javax.swing.JFrame {

    /**
     * Creates new form Login
     */
    private String username, password, confirmpassword, email, tel, sql, textuser, textpassword,
            textemail, textphonenumber, pass1, pass2;
    int UpdateRowCount;
    private Connection con;
    private PreparedStatement pst;
    private ResultSet rs;
    private Login login;
    private Pattern patt;
    private Matcher match;

    public SignUp() {
        initComponents();
    }

        public void insertRegister() {
            username = regis_user.getText();
            confirmpassword = regis_cfpass.getText();
            email = regis_email.getText();
            tel = regis_tel.getText();

            try {
                con = DBConnection.getConnection();
                sql = "insert into users(username,password,email,phonenumber) values(?,?,?,?)";
                pst = con.prepareStatement(sql);
                pst.setString(1, username);
                pst.setString(2, password);
                pst.setString(3, email);
                pst.setString(4, tel);
                UpdateRowCount = pst.executeUpdate();
                if (UpdateRowCount > 0) {
                    JOptionPane.showMessageDialog(this, "Recorded Inserted Successfully");
                } else {
                    JOptionPane.showMessageDialog(this, "Recorded Inserted Fail");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    public boolean validateRegister() {
        username = regis_user.getText();
        password = regis_pass.getText();
        confirmpassword = regis_cfpass.getText();
        email = regis_email.getText();
        tel = regis_tel.getText();
        boolean checkemail = isValid(email);
        boolean checktel = validatePhoneNumber(tel);
        if (username.equals("")) {
            JOptionPane.showMessageDialog(this, "please enter username");
            return false;
        }

        if (password.equals("")) {
            JOptionPane.showMessageDialog(this, "please enter password");
            return false;
        }

        if (confirmpassword.equals("")) {
            JOptionPane.showMessageDialog(this, "please enter confirm password");
            return false;
        }

        if (email.equals("")) {
            JOptionPane.showMessageDialog(this, "please enter email");
            return false;
        }

        if (checkemail == false) {
            JOptionPane.showMessageDialog(this, "invalid email");
            return false;
        }

        if (!password.equals(confirmpassword)) {
            JOptionPane.showMessageDialog(this, "password would not be matched");
            return false;
        }

        if (tel.equals("")) {
            JOptionPane.showMessageDialog(this, "please enter phonenumber");
            return false;
        }

        if (checktel == false) {
            JOptionPane.showMessageDialog(this, "invalid phonenumber");
            return false;
        }

        return true;
    }

    private static boolean validatePhoneNumber(String phoneNumber) {
        // validate phone numbers of format "1234567890"
        if (phoneNumber.matches("\\d{10}")) {
            return true;
        } // validating phone number with -, . or spaces
        else if (phoneNumber.matches("\\d{3}[-\\.\\s]\\d{3}[-\\.\\s]\\d{4}")) {
            return true;
        } // validating phone number with extension length from 3 to 5
        else if (phoneNumber.matches("\\d{3}-\\d{3}-\\d{4}\\s(x|(ext))\\d{3,5}")) {
            return true;
        } // validating phone number where area code is in braces ()
        else if (phoneNumber.matches("\\(\\d{3}\\)-\\d{3}-\\d{4}")) {
            return true;
        } // Validation for India numbers
        else if (phoneNumber.matches("\\d{4}[-\\.\\s]\\d{3}[-\\.\\s]\\d{3}")) {
            return true;
        } else if (phoneNumber.matches("\\(\\d{5}\\)-\\d{3}-\\d{3}")) {
            return true;
        } else if (phoneNumber.matches("\\(\\d{4}\\)-\\d{3}-\\d{3}")) {
            return true;
        } // return false if nothing matches the input
        else {
            return false;
        }

    }

    public static boolean isValid(String email) {
        String regex = "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[\\a-zA-Z]{2,6}";
        Pattern pattern = Pattern.compile(regex);
        if (email == null) {
            return false;
        }
        return pattern.matcher(email).matches();
    }

    public boolean checkDuplicateUser() {
        username = regis_user.getText();
        boolean isExist = false;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library_ms", "root", "");
            pst = con.prepareStatement("select * from users where username = ?");
            pst.setString(1, username);
            rs = pst.executeQuery();
            if (rs.next()) {
                isExist = true;
            } else {
                isExist = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isExist;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel5 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        regis_user = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        regis_pass = new javax.swing.JPasswordField();
        jPanel11 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        regis_cfpass = new javax.swing.JPasswordField();
        jLabel9 = new javax.swing.JLabel();
        regis_email = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        regis_tel = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        rSMaterialButtonCircle2 = new rojerusan.RSMaterialButtonCircle();
        rSMaterialButtonCircle3 = new rojerusan.RSMaterialButtonCircle();
        checku = new javax.swing.JLabel();
        checkp = new javax.swing.JLabel();
        checkpp = new javax.swing.JLabel();
        checke = new javax.swing.JLabel();
        checkphone = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        jPanel5.setBackground(new java.awt.Color(255, 51, 51));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 41, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(94, 92, 200));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Sign Up");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 40, -1, -1));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Sign up your account.");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 90, -1, -1));

        regis_user.setBackground(new java.awt.Color(48, 47, 141));
        regis_user.setForeground(new java.awt.Color(255, 255, 255));
        regis_user.setBorder(null);
        regis_user.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                regis_userKeyReleased(evt);
            }
        });
        jPanel1.add(regis_user, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 160, 259, 38));

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Username");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 140, -1, -1));

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Password");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 210, -1, -1));

        regis_pass.setBackground(new java.awt.Color(48, 47, 141));
        regis_pass.setForeground(new java.awt.Color(255, 255, 255));
        regis_pass.setBorder(null);
        regis_pass.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                regis_passKeyReleased(evt);
            }
        });
        jPanel1.add(regis_pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 230, 259, 38));

        jPanel11.setBackground(new java.awt.Color(255, 51, 102));
        jPanel11.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel11.setPreferredSize(new java.awt.Dimension(60, 45));
        jPanel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel11MouseClicked(evt);
            }
        });
        jPanel11.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("X");
        jPanel11.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 12, -1, -1));

        jPanel1.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 0, 60, -1));

        jPanel12.setBackground(new java.awt.Color(0, 0, 255));
        jPanel12.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel12.setPreferredSize(new java.awt.Dimension(60, 45));
        jPanel12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel12MouseClicked(evt);
            }
        });
        jPanel12.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("-");
        jPanel12.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 12, -1, 20));

        jPanel1.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 0, -1, -1));

        regis_cfpass.setBackground(new java.awt.Color(48, 47, 141));
        regis_cfpass.setForeground(new java.awt.Color(255, 255, 255));
        regis_cfpass.setBorder(null);
        regis_cfpass.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                regis_cfpassKeyReleased(evt);
            }
        });
        jPanel1.add(regis_cfpass, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 300, 259, 38));

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Confirm Password");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 280, -1, -1));

        regis_email.setBackground(new java.awt.Color(48, 47, 141));
        regis_email.setForeground(new java.awt.Color(255, 255, 255));
        regis_email.setBorder(null);
        regis_email.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                regis_emailKeyReleased(evt);
            }
        });
        jPanel1.add(regis_email, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 370, 259, 38));

        jLabel11.setBackground(new java.awt.Color(255, 255, 255));
        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Email");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 350, -1, -1));

        jLabel12.setBackground(new java.awt.Color(255, 255, 255));
        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Phone number");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 420, -1, -1));

        regis_tel.setBackground(new java.awt.Color(48, 47, 141));
        regis_tel.setForeground(new java.awt.Color(255, 255, 255));
        regis_tel.setBorder(null);
        regis_tel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                regis_telKeyReleased(evt);
            }
        });
        jPanel1.add(regis_tel, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 440, 259, 38));

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/email.png"))); // NOI18N
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 370, 40, 30));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/user.png"))); // NOI18N
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 160, 30, 30));

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/lock.png"))); // NOI18N
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 230, 30, 30));

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/phone.png"))); // NOI18N
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 440, 30, 30));

        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/conlock.png"))); // NOI18N
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 300, 30, 30));

        rSMaterialButtonCircle2.setBackground(new java.awt.Color(255, 255, 255));
        rSMaterialButtonCircle2.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonCircle2.setText("Login");
        rSMaterialButtonCircle2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonCircle2ActionPerformed(evt);
            }
        });
        jPanel1.add(rSMaterialButtonCircle2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 570, 259, 67));

        rSMaterialButtonCircle3.setBackground(new java.awt.Color(217, 26, 118));
        rSMaterialButtonCircle3.setText("SIgn Up");
        rSMaterialButtonCircle3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonCircle3ActionPerformed(evt);
            }
        });
        jPanel1.add(rSMaterialButtonCircle3, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 500, 259, 67));

        checku.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        checku.setForeground(new java.awt.Color(255, 131, 153));
        jPanel1.add(checku, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 195, 200, -1));

        checkp.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        checkp.setForeground(new java.awt.Color(255, 131, 153));
        jPanel1.add(checkp, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 265, 200, -1));

        checkpp.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        checkpp.setForeground(new java.awt.Color(255, 131, 153));
        jPanel1.add(checkpp, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 335, 200, -1));

        checke.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        checke.setForeground(new java.awt.Color(255, 131, 153));
        jPanel1.add(checke, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 405, 200, -1));

        checkphone.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        checkphone.setForeground(new java.awt.Color(255, 131, 153));
        jPanel1.add(checkphone, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 475, 200, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/login (2) (1).jpg"))); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(92, 92, 92)
                .addComponent(jLabel6)
                .addGap(117, 117, 117)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 654, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(299, 299, 299)
                        .addComponent(jLabel7))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(115, 115, 115)
                        .addComponent(jLabel6)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void rSMaterialButtonCircle1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonCircle1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rSMaterialButtonCircle1ActionPerformed

    private void rSMaterialButtonCircle2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonCircle2ActionPerformed
        login.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_rSMaterialButtonCircle2ActionPerformed

    private void jPanel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel11MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jPanel11MouseClicked

    private void jPanel12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel12MouseClicked
        this.setExtendedState(SignUp.ICONIFIED);
    }//GEN-LAST:event_jPanel12MouseClicked

    private void rSMaterialButtonCircle3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonCircle3ActionPerformed
        if (validateRegister() == true) {
            insertRegister();
        }
    }//GEN-LAST:event_rSMaterialButtonCircle3ActionPerformed

    private void regis_userKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_regis_userKeyReleased
        textuser = "^[a-zA-Z0-9]{5,30}$";
        patt = Pattern.compile(textuser);
        match = patt.matcher(regis_user.getText());
        if (!match.matches()) {
            checku.setText("Please check your username");
        } else {
            checku.setText("");
        }
    }//GEN-LAST:event_regis_userKeyReleased

    private void regis_passKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_regis_passKeyReleased
        textpassword = "^[a-zA-Z0-9]{5,30}$";
        patt = Pattern.compile(textpassword);
        match = patt.matcher(regis_pass.getText());
        if (!match.matches()) {
            checkp.setText("Invalid password format");
        } else {
            checkp.setText("");
        }
    }//GEN-LAST:event_regis_passKeyReleased

    private void regis_cfpassKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_regis_cfpassKeyReleased
        pass1 = String.valueOf(regis_pass.getPassword());
        pass2 = String.valueOf(regis_cfpass.getPassword());
        if (pass1.equals(pass2)) {
            checkpp.setText("");
        } else {

            checkpp.setText("Password doesn't match");
        }
    }//GEN-LAST:event_regis_cfpassKeyReleased

    private void regis_emailKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_regis_emailKeyReleased
        textemail = "^[a-zA-Z0-9]{0,30}[@][a-zA-z0-9]{0,20}[.][a-zA-z0-9]{0,20}$";
        patt = Pattern.compile(textemail);
        match = patt.matcher(regis_email.getText());
        if (!match.matches()) {
            checke.setText("Invalid Email");
        } else {
            checke.setText("");
        }
    }//GEN-LAST:event_regis_emailKeyReleased

    private void regis_telKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_regis_telKeyReleased
        textphonenumber = "^[0-9]{10,10}$";
        patt = Pattern.compile(textphonenumber);
        match = patt.matcher(regis_tel.getText());
        if (!match.matches()) {
            checkphone.setText("Please check your phonenumber");
        } else {
            checkphone.setText("");
        }
    }//GEN-LAST:event_regis_telKeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SignUp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SignUp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SignUp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SignUp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SignUp().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel checke;
    private javax.swing.JLabel checkp;
    private javax.swing.JLabel checkphone;
    private javax.swing.JLabel checkpp;
    private javax.swing.JLabel checku;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private rojerusan.RSMaterialButtonCircle rSMaterialButtonCircle2;
    private rojerusan.RSMaterialButtonCircle rSMaterialButtonCircle3;
    private javax.swing.JPasswordField regis_cfpass;
    private javax.swing.JTextField regis_email;
    private javax.swing.JPasswordField regis_pass;
    private javax.swing.JTextField regis_tel;
    private javax.swing.JTextField regis_user;
    // End of variables declaration//GEN-END:variables
}
