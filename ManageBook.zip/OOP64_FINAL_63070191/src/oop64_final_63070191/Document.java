
public class Document {
    private String name;
    private String type;
    private String detail;

    public Document() {
        this.name = null;
        this.type = null;
        this.detail = null;
    }
    
    public Document(String name, String type, String detail) {
        this.name = name;
        this.type = type;
        this.detail = detail;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }
    
    
    
}
