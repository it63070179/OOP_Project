

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.*;
public class DocumentDetailView {
    private JFrame fr;
     private JTextArea ta;
     private JPanel p1;

    public DocumentDetailView() {
        fr = new JFrame("DocumentDetailView");
        p1 = new JPanel();
        ta =  new JTextArea( 5, 20);
        
        
        p1.add(ta);
        fr.add(p1);
        fr.setSize(250, 150);
 fr.setLocationRelativeTo(null);
 
fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 fr.setVisible(true);
    }
   

    DocumentDetailView(DocumentMainView aThis) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
     
}
