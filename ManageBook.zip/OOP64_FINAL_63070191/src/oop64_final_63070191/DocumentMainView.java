
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.*;
public class DocumentMainView implements 
ActionListener, WindowListener {
 private JFrame fr;
 private JPanel p1, p2, p3, p4, p5,p6,p7;
 private JLabel lb1, lb2, lb3;
 private JTextField tf1, tf2,  tf4;
 private JTextArea ta;
 private JButton left, right, add, 
update, delete;
 private JComboBox type;
 private ArrayList<Document> document = new ArrayList<Document>();


 public DocumentMainView() {
 fr = new JFrame("DocumentMainView");
 p1 = new JPanel();
 p2 = new JPanel();
 p3 = new JPanel();
 p4 = new JPanel();
 p5 = new JPanel();
 p6=new JPanel();
 p7 = new JPanel();

 
 lb1 = new JLabel(" Title ");
 lb2 = new JLabel(" Type ");
 lb3 = new JLabel(" Detail ");
 tf1 = new JTextField(16);
 tf2 = new JTextField(10);
 ta =  new JTextArea( 5, 20);
 String combo[] = {"Normal", 
"Formal", "Informal", "etc"};
 type = new JComboBox(combo);

 
 left = new JButton("Previous");
 tf4 = new JTextField("0",1);
 right = new JButton("Next");
 add = new JButton("Add");
 update = new JButton("Update");
 delete = new JButton("Delete");
 
 left.addActionListener(this);
 right.addActionListener(this);
 add.addActionListener(this);
 update.addActionListener(this);
 delete.addActionListener(this);

 p1.add(lb1);
 p1.add(tf1);

 
 p2.add(lb2);
 p2.add(type);
 p3.setLayout(new GridLayout(1,1));
 p3.add(p2);
 p7.setLayout(new GridLayout(1,1));
 p7.add(lb3);
 p6.setLayout(new GridLayout(1,2));
 p6.add(ta);
 
 fr.setLayout(new GridLayout(6,1));
 fr.add(p1);
 fr.add(p3);
 fr.add(p7);
 fr.add(p6);
 
 
 p4.add(left);
 p4.add(tf4);
 p4.add(right);
 
 p5.add(add);
 p5.add(update);
 p5.add(delete);
 fr.add(p4);
 fr.add(p5);
 
 fr.setSize(250, 300);
 fr.setLocationRelativeTo(null);
 
fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 fr.setVisible(true);
 
 
}
   

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource().equals(add)) {
        new DocumentDetailView();
 } 

 
    }

    @Override
    public void windowOpened(WindowEvent we) {
       
    }

    @Override
    public void windowClosing(WindowEvent we) {
        
    }

    @Override
    public void windowClosed(WindowEvent we) {
 
    }

    @Override
    public void windowIconified(WindowEvent we) {
        
    }

    @Override
    public void windowDeiconified(WindowEvent we) {
   
    }

    @Override
    public void windowActivated(WindowEvent we) {
       
    }

    @Override
    public void windowDeactivated(WindowEvent we) {
        
    }
    
}